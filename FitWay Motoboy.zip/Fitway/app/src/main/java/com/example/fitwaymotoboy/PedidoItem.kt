package com.example.fitwaymotoboy

// Isso é apenas a estrutura de dados que a lista usa para organizar as informações do Firebase
data class PedidoItem(
    val id: String = "",
    val numero: String = "",
    val restauranteNome: String = "",
    val restauranteEndereco: String = "",
    val clienteEndereco: String = "",
    val valorCarga: Double = 0.0,
    val taxaEntrega: Double = 0.0,
    val formaPagamento: String = "",
    val itensResumo: String = "",
    val emailConsumidor: String = ""
)