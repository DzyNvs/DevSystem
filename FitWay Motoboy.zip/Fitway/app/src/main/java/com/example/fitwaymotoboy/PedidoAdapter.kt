package com.example.fitwaymotoboy

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class PedidoAdapter(
    private val onClick: (PedidoItem) -> Unit
) : ListAdapter<PedidoItem, PedidoAdapter.VH>(DIFF) {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txtNumero     : TextView = view.findViewById(R.id.txtCardNumero)
        val txtRestaurante: TextView = view.findViewById(R.id.txtCardRestaurante)
        val txtItens      : TextView = view.findViewById(R.id.txtCardItens)
        val txtFrete      : TextView = view.findViewById(R.id.txtCardFrete)
        val txtPagamento  : TextView = view.findViewById(R.id.txtCardPagamento)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pedido, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        holder.txtNumero.text      = "Pedido #${item.numero}"
        holder.txtRestaurante.text = item.restauranteNome
        holder.txtItens.text       = item.itensResumo
        holder.txtFrete.text       = "R$ ${"%.2f".format(item.taxaEntrega).replace('.', ',')}"
        holder.txtPagamento.text   = item.formaPagamento
        holder.itemView.setOnClickListener { onClick(item) }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<PedidoItem>() {
            override fun areItemsTheSame(a: PedidoItem, b: PedidoItem) = a.id == b.id
            override fun areContentsTheSame(a: PedidoItem, b: PedidoItem) = a == b
        }
    }
}
