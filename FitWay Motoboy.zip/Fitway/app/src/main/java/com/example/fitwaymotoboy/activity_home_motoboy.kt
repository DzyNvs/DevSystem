package com.example.fitwaymotoboy

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

// Nota: se o seu arquivo fisicamente se chama activity_home_motoboy, mantenha o nome abaixo.
// O padrão recomendado pelo Android é iniciar classes com letra maiúscula (HomeMotoboyActivity).
class activity_home_motoboy : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Define o layout da tela de gerenciamento
        setContentView(R.layout.activity_home_motoboy)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Mapeando os componentes do XML que criamos
        val txtNome = findViewById<TextView>(R.id.txtNomeMotoboy)
        val txtId = findViewById<TextView>(R.id.txtIdMotoboy)
        val btnSair = findViewById<ImageButton>(R.id.btnSairPainel)

        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Busca os dados do motoboy logado direto no banco Firestore
            db.collection("entregadores").document(currentUser.uid)
                .get()
                .addOnSuccessListener { document ->
                    if (document != null && document.exists()) {
                        val nomeCompleto = document.getString("nome") ?: "Motoboy"
                        val idMoto = document.getString("id_motoboy") ?: "000000"

                        // Atualiza a tela com os dados do Firebase
                        txtNome.text = "Olá, $nomeCompleto"
                        txtId.text = "● Online (ID: $idMoto)"
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Erro ao carregar dados do perfil: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }

        // Ação para o botão de fechar/sair (desloga do Firebase e volta para o Login)
        btnSair.setOnClickListener {
            auth.signOut()
            Toast.makeText(this, "Sessão encerrada!", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}