package com.example.fitwaymotoboy

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()

        val editEmail = findViewById<EditText>(R.id.editEmail)
        val editSenha = findViewById<EditText>(R.id.editCodigo)
        val btnEntrar = findViewById<Button>(R.id.btnReceberCodigo)
        val txtCadastrese = findViewById<TextView>(R.id.txtCadastrese)

        editSenha.hint = "Digite sua senha"
        btnEntrar.text = "Entrar"

        btnEntrar.setOnClickListener {
            val email = editEmail.text.toString().trim()
            val senha = editSenha.text.toString().trim()

            if (email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha o e-mail e a senha!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.signInWithEmailAndPassword(email, senha)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        val user = auth.currentUser

                        if (user != null && user.isEmailVerified) {
                            Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()

                            // ─── DEFINIDO COM O NOME EXATO QUE VOCÊ PASSOU ───
                            val intent = Intent(this, activity_home_motoboy::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            Toast.makeText(this, "Acesso Negado! Por favor, ative o link enviado ao seu e-mail.", Toast.LENGTH_LONG).show()
                            auth.signOut()
                        }
                    } else {
                        Toast.makeText(this, "Erro ao logar: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }

        txtCadastrese.setOnClickListener {
            val intent = Intent(this, CadastroMotoboyActivity::class.java)
            startActivity(intent)
        }
    }
}