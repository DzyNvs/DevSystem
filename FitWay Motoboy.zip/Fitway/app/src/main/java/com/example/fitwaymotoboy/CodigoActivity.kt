package com.example.fitwaymotoboy

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class CodigoActivity : AppCompatActivity() {

    private val API_URL = "http://192.168.0.137:3000"
    private val client = OkHttpClient()
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private var emailUsuario: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_codigo)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Captura o e-mail vindo da MainActivity
        emailUsuario = intent.getStringExtra("email_usuario")

        val editCodigo = findViewById<EditText>(R.id.editCodigo) // certifique-se que o id no xml é editCodigo
        val btnVerificar = findViewById<Button>(R.id.btnVerificar) // certifique-se que o id é btnVerificar

        btnVerificar.setOnClickListener {
            val codigo = editCodigo.text.toString().trim()

            if (codigo.length < 6) {
                Toast.makeText(this, "Digite o código completo de 6 dígitos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (emailUsuario != null) {
                btnVerificar.isEnabled = false
                validarCodigoNoServidor(emailUsuario!!, codigo, btnVerificar)
            }
        }
    }

    private fun validarCodigoNoServidor(email: String, codigo: String, botao: Button) {
        val json = JSONObject()
        json.put("email", email)
        json.put("codigo", codigo)

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val body = json.toString().toRequestBody(mediaType)

        val request = Request.Builder()
            .url("$API_URL/verificar-codigo-login")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    botao.isEnabled = true
                    Toast.makeText(this@CodigoActivity, "Erro ao conectar ao servidor.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()

                runOnUiThread {
                    botao.isEnabled = true
                    if (response.isSuccessful && responseBody != null) {
                        val jsonResposta = JSONObject(responseBody)
                        val customToken = jsonResposta.getString("token")

                        // Autentica o app usando o Token gerado pelo Node.js
                        fazerLoginComToken(customToken)
                    } else {
                        val msgErro = try {
                            JSONObject(responseBody ?: "").getString("erro")
                        } catch (e: Exception) {
                            "Código inválido ou expirado."
                        }
                        Toast.makeText(this@CodigoActivity, msgErro, Toast.LENGTH_LONG).show()
                    }
                }
            }
        })
    }

    private fun fazerLoginComToken(token: String) {
        auth.signInWithCustomToken(token).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val uid = auth.currentUser?.uid
                if (uid != null) {
                    verificarSeEEntregador(uid)
                }
            } else {
                Toast.makeText(this, "Falha na autenticação do Firebase.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun verificarSeEEntregador(uid: String) {
        // Verifica se o usuário que logou realmente pertence à coleção dos motoboys
        db.collection("entregadores").document(uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    Toast.makeText(this, "Acesso concedido com sucesso!", Toast.LENGTH_SHORT).show()

                    // 🚀 DESTINO FINAL: Direciona para a sua tela de Gestão de Pedidos
                    // (Substitua MainActivity pelo nome da sua Activity de Pedidos caso mude)
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finishAffinity()
                } else {
                    auth.signOut()
                    Toast.makeText(this, "Acesso negado: Usuário não é um entregador.", Toast.LENGTH_LONG).show()
                }
            }
            .addOnFailureListener {
                auth.signOut()
                Toast.makeText(this, "Erro ao verificar permissões no banco.", Toast.LENGTH_SHORT).show()
            }
    }
}