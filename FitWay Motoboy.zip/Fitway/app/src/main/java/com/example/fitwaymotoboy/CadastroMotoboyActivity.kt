package com.example.fitwaymotoboy

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CadastroMotoboyActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro_motoboy)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val editNome = findViewById<EditText>(R.id.editNome)
        val editEmail = findViewById<EditText>(R.id.editEmail)
        val editCpf = findViewById<EditText>(R.id.editCpf)
        val editTelefone = findViewById<EditText>(R.id.editTelefone)
        val editPlaca = findViewById<EditText>(R.id.editPlaca)
        val editSenha = findViewById<EditText>(R.id.editSenhaCadastro) // Mapeado o novo campo
        val btnCadastrar = findViewById<Button>(R.id.btnCadastrar)

        btnCadastrar.setOnClickListener {
            val nome = editNome.text.toString().trim()
            val email = editEmail.text.toString().trim()
            val cpf = editCpf.text.toString().trim()
            val telefone = editTelefone.text.toString().trim()
            val placa = editPlaca.text.toString().trim()
            val senhaCadastro = editSenha.text.toString().trim() // Captura a senha digitada

            if (nome.isEmpty() || email.isEmpty() || cpf.isEmpty() || telefone.isEmpty() || placa.isEmpty() || senhaCadastro.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (senhaCadastro.length < 6) {
                Toast.makeText(this, "A senha deve ter no mínimo 6 caracteres!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Cria o usuário no Firebase Authentication com a senha do usuário
            auth.createUserWithEmailAndPassword(email, senhaCadastro)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        val userId = auth.currentUser?.uid

                        // Envia o e-mail de verificação em segundo plano
                        auth.currentUser?.sendEmailVerification()

                        if (userId != null) {
                            salvarDadosNoFirestore(userId, nome, email, cpf, telefone, placa)
                        }
                    } else {
                        Toast.makeText(this, "Erro no cadastro: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }
    }

    private fun salvarDadosNoFirestore(userId: String, nome: String, email: String, cpf: String, telefone: String, placa: String) {
        val dateFormat = SimpleDateFormat("dd 'de' MMMM 'de' yyyy 'às' HH:mm:ss 'UTC-3'", Locale("pt", "BR"))
        val dataCriacao = dateFormat.format(Date())

        val idMotoboy = "moto_${(100000..999999).random()}"

        val motoboyData = hashMapOf(
            "cpf" to cpf,
            "data_criacao" to dataCriacao,
            "email" to email,
            "id_motoboy" to idMotoboy,
            "nome" to nome,
            "placa_veiculo" to placa,
            "status_online" to false,
            "telefone" to telefone,
            "tipo" to "motoboy"
        )

        db.collection("entregadores").document(userId)
            .set(motoboyData)
            .addOnSuccessListener {
                Toast.makeText(this, "Motoboy cadastrado com sucesso!", Toast.LENGTH_LONG).show()
                finish() // Encerra o cadastro e retorna à tela de login
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao salvar dados no Firestore: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}