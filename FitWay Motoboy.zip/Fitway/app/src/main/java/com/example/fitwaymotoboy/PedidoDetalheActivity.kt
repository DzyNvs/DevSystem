package com.example.fitwaymotoboy

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

class PedidoDetalheActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pedido_detalhe)

        db   = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        // ── Dados recebidos da HomeMotoboyActivity ──────────────────────────
        val pedidoId     = intent.getStringExtra("pedido_id") ?: return
        val numero       = intent.getStringExtra("pedido_numero") ?: ""
        val restNome     = intent.getStringExtra("restaurante_nome") ?: "—"
        val restEnd      = intent.getStringExtra("restaurante_endereco") ?: "—"
        val clienteEnd   = intent.getStringExtra("cliente_endereco") ?: "—"
        val valorCarga   = intent.getDoubleExtra("valor_carga", 0.0)
        val taxaEntrega  = intent.getDoubleExtra("taxa_entrega", 0.0)
        val pagamento    = intent.getStringExtra("forma_pagamento") ?: "—"
        val itensResumo  = intent.getStringExtra("itens_resumo") ?: "—"

        // ── Views ───────────────────────────────────────────────────────────
        findViewById<TextView>(R.id.txtDetalheNumero).text    = "Pedido #$numero"
        findViewById<TextView>(R.id.txtDetalheItens).text     = itensResumo
        findViewById<TextView>(R.id.txtOrigemNome).text       = restNome
        findViewById<TextView>(R.id.txtOrigemEnd).text        = restEnd
        findViewById<TextView>(R.id.txtDestinoEnd).text       = clienteEnd
        findViewById<TextView>(R.id.txtDetalheValor).text     =
            "R$ ${"%.2f".format(valorCarga).replace('.', ',')}"
        findViewById<TextView>(R.id.txtDetalheFrete).text     =
            "R$ ${"%.2f".format(taxaEntrega).replace('.', ',')}"
        findViewById<TextView>(R.id.txtDetalhePagamento).text = pagamento

        val editCodigo    = findViewById<EditText>(R.id.editCodigoEntrega)
        val btnConfirmar  = findViewById<Button>(R.id.btnConfirmarEntrega)
        val btnVoltar     = findViewById<ImageButton>(R.id.btnVoltarDetalhe)
        val txtStatus     = findViewById<TextView>(R.id.txtStatusCodigo)

        btnVoltar.setOnClickListener { finish() }

        // ── Confirmar entrega com o código de 4 dígitos ────────────────────
        btnConfirmar.setOnClickListener {
            val codigoDigitado = editCodigo.text.toString().trim()

            if (codigoDigitado.length != 4) {
                txtStatus.text      = "⚠ O código deve ter exatamente 4 dígitos."
                txtStatus.setTextColor(Color.parseColor("#E53935"))
                txtStatus.visibility = android.view.View.VISIBLE
                return@setOnClickListener
            }

            btnConfirmar.isEnabled = false
            btnConfirmar.text      = "Verificando..."

            // Busca o pedido e compara o código
            db.collection("pedidos").document(pedidoId)
                .get()
                .addOnSuccessListener { doc ->
                    val codigoCorreto = doc.getString("codigo_entrega") ?: ""

                    if (codigoDigitado == codigoCorreto) {
                        // ✅ Código correto → finaliza o pedido
                        finalizarPedido(pedidoId, doc.getString("email_consumidor") ?: "",
                            itensResumo, valorCarga, taxaEntrega, valorCarga + taxaEntrega, txtStatus, btnConfirmar)
                    } else {
                        // ❌ Código errado
                        txtStatus.text      = "❌ Código incorreto. Peça ao cliente para confirmar."
                        txtStatus.setTextColor(Color.parseColor("#E53935"))
                        txtStatus.visibility = android.view.View.VISIBLE
                        btnConfirmar.isEnabled = true
                        btnConfirmar.text      = "Confirmar Entrega"
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Erro ao verificar pedido.", Toast.LENGTH_SHORT).show()
                    btnConfirmar.isEnabled = true
                    btnConfirmar.text      = "Confirmar Entrega"
                }
        }
    }

    private fun finalizarPedido(
        pedidoId: String,
        emailCliente: String,
        itens: String,
        subtotal: Double,
        frete: Double,
        total: Double,
        txtStatus: TextView,
        btnConfirmar: Button
    ) {
        // 1. Atualiza o status no Firestore
        db.collection("pedidos").document(pedidoId)
            .update("status", "entregue")
            .addOnSuccessListener {
                // 2. Dispara a nota fiscal no backend Node.js (mesmo do FitWay)
                enviarNotaFiscal(pedidoId, emailCliente, itens, subtotal, frete, total)

                txtStatus.text      = "✅ Entrega confirmada com sucesso!"
                txtStatus.setTextColor(Color.parseColor("#2E7D32"))
                txtStatus.visibility = android.view.View.VISIBLE
                btnConfirmar.isEnabled = false
                btnConfirmar.text      = "Entrega Concluída ✓"
                btnConfirmar.backgroundTintList =
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#2E7D32"))

                // Volta para o painel após 2 segundos
                android.os.Handler(mainLooper).postDelayed({ finish() }, 2000)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Erro ao finalizar pedido.", Toast.LENGTH_SHORT).show()
                btnConfirmar.isEnabled = true
                btnConfirmar.text      = "Confirmar Entrega"
            }
    }

    private fun enviarNotaFiscal(
        pedidoId: String, email: String, itensResumo: String,
        subtotal: Double, frete: Double, total: Double
    ) {
        // Chama o endpoint /enviar-nota-fiscal do backend FitWay
        val urlBackend = "http://192.168.0.137:3000/enviar-nota-fiscal"

        val json = org.json.JSONObject().apply {
            put("idPedido",    pedidoId)
            put("email",       email)
            put("subtotal",    subtotal)
            put("taxaEntrega", frete)
            put("totalFinal",  total)
            put("itens",       org.json.JSONArray().put(
                org.json.JSONObject().put("nome", itensResumo).put("qtd", 1).put("preco", subtotal)
            ))
        }

        // ─── CORREÇÃO DOS TIPOS AQUI ───
        // Criação explícita utilizando os imports nativos e recomendados do OkHttp 4.x
        val mediaType: okhttp3.MediaType = "application/json; charset=utf-8".toMediaType()
        val body: okhttp3.RequestBody = json.toString().toRequestBody(mediaType)

        val request = okhttp3.Request.Builder()
            .url(urlBackend)
            .post(body)
            .build()

        okhttp3.OkHttpClient().newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                // Falha silenciosa — o pedido já foi finalizado no Firestore
            }
            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                // Fecha a resposta para não vazar memória
                response.close()
            }
        })
    }
}