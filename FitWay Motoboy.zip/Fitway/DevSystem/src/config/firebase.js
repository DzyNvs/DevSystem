import AsyncStorage from '@react-native-async-storage/async-storage';
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";


import { getReactNativePersistence, initializeAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyABqUR1DTGlBAvExdWBg3Os4ixY1SGk3tI",
  authDomain: "fitway-98104.firebaseapp.com",
  projectId: "fitway-98104",
  storageBucket: "fitway-98104.firebasestorage.app",
  messagingSenderId: "613129940263",
  appId: "1:613129940263:web:3e66c85e0ccc91a3734d02"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);

// Ativando a persistência no celular
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage)
});

export { auth, db, storage };

